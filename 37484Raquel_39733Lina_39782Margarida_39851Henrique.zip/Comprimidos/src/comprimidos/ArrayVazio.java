package comprimidos;
    
   public class ArrayVazio extends Exception{
       
       public ArrayVazio(){
           super();
   }
       
   public ArrayVazio(String s){
       super(s);
   }
}
